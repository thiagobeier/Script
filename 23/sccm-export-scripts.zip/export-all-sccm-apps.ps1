﻿################################################################################   
#Author Thiago Beier thiago.beier@gmail.com   
#Version: 2.0 - 2020-01-22 
#Export SCCM Apps and its contents
#Export each apps separately 
#Tested with SCCM Version: 1902 
#Toronto,CANADA   
#email: thiago.beier@gmail.com 
#https://www.linkedin.com/in/tbeier/ 
#version: 2.0
################################################################################  

$exportpath = "D:\Export"

$targetfolder = "$exportpath\apps"

if(!(Test-Path -Path $targetfolder )){
    New-Item -ItemType directory -Path $targetfolder
    Write-Host "New folder created" -ForegroundColor Green
}
else
{
  Write-Host "Folder already exists" -ForegroundColor Red
}

$listappsname = Get-CMApplication | select LocalizedDisplayName
foreach ($appname in $listappsname) {
    $appsname = $appname.LocalizedDisplayName
    write-host $appsname -ForegroundColor Green
    Export-CMApplication -Name $appsname -Path $targetfolder\$appsname.zip
  }