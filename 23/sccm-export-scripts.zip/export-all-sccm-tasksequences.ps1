﻿################################################################################   
#Author Thiago Beier thiago.beier@gmail.com   
#Version: 2.0 - 2020-01-22  
#Export SCCM Task Sequences
#Export each TS separately 
#Tested with SCCM Version: 1902 
#Toronto,CANADA   
#email: thiago.beier@gmail.com 
#https://www.linkedin.com/in/tbeier/ 
################################################################################  

$exportpath = "D:\Export"

$targetfolder = "$exportpath\ts"

if(!(Test-Path -Path $targetfolder )){
    New-Item -ItemType directory -Path $targetfolder
    Write-Host "New folder created" -ForegroundColor Green
}
else
{
  Write-Host "Folder already exists" -ForegroundColor Red
}


$querylist = Get-CMTaskSequence | select name
foreach ($queryitem in $querylist) {
    $name = $queryitem.name
    #write-host querylist -ForegroundColor Green
    write-host $name -ForegroundColor Green
    Export-CMTaskSequence -Name $name -WithDependence $True -WithContent $True -ErrorAction Continue -ExportFilePath $targetfolder\$name.zip
  }

