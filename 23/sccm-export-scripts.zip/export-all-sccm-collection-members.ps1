﻿################################################################################   
#Author Thiago Beier thiago.beier@gmail.com   
#Version: 2.0 - 2020-01-22 
#Export SCCM Collections info
#Export each collection info separately 
#Tested with SCCM Version: 1902 
#Toronto,CANADA   
#email: thiago.beier@gmail.com 
#https://www.linkedin.com/in/tbeier/ 
################################################################################  

$exportpath = "D:\Export"

$targetfolder = "$exportpath\collections"

if(!(Test-Path -Path $targetfolder )){
    New-Item -ItemType directory -Path $targetfolder
    Write-Host "New folder created" -ForegroundColor Green
}
else
{
  Write-Host "Folder already exists" -ForegroundColor Red
}

#Get-CMCollection
$querylist = Get-CMCollection  #| select collectionid,name
foreach ($queryitem in $querylist) {
    $name = $queryitem.Name
    $colid = $queryitem.collectionid
    write-host $name -ForegroundColor Green
    Write-Host $colid-$name -ForegroundColor Yellow
    Get-CMCollection -Id $colid | Get-CMCollectionMember | select Name,primaryuser,lastlogonuser,currentlogonuser,adsitename | Export-csv "$targetfolder\$colid-$name.csv" -Encoding UTF8
  }
