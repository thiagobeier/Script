﻿################################################################################   
#Author Thiago Beier thiago.beier@gmail.com   
#Version: 2.0 - 2020-01-22 
#Export SCCM Packages and its contents
#Export each package separately 
#Tested with SCCM Version: 1902 
#Toronto,CANADA   
#email: thiago.beier@gmail.com 
#https://www.linkedin.com/in/tbeier/ 
################################################################################  

$exportpath = "D:\Export"

$targetfolder = "$exportpath\pkg"

if(!(Test-Path -Path $targetfolder )){
    New-Item -ItemType directory -Path $targetfolder
    Write-Host "New folder created" -ForegroundColor Green
}
else
{
  Write-Host "Folder already exists" -ForegroundColor Red
}

$listpackage = Get-CMPackage | select Name
foreach ($pkgname in $listpackage) {
    $name = $pkgname.Name
    #write-host $pkgname.Name -ForegroundColor Green
    write-host $name -ForegroundColor Green
    Export-CMPackage -Name $name -ExportFilePath $targetfolder\$name.zip
  }
