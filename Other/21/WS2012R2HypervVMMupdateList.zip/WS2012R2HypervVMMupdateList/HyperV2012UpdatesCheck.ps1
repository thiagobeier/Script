﻿#  Copyright (C) 2015 by Thiago Beier (thiago.beier@gmail.com)
#  All Rights Reserved.

#  Updates List for Hyper-v Windows Server 2012 R2 and VMM 2012 R2
#  KB URL https://support.microsoft.com/en-us/kb/2974503 Last Reviewed 06/26/2015
#  Keeps your Hyper-v Cluster and VMM 2012/R2 updated during the setup.

$userAgent = "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:7.0.1) Gecko/20100101 Firefox/7.0.1"
$web = New-Object System.Net.WebClient
$web.Headers.Add("user-agent", $userAgent)
#if ISE run this and comment the line below $dir = Split-Path $scriptpath
$dir = Split-Path $MyInvocation.MyCommand.Path
Write-Output $dir

# Create the destination folder if it doesn't exist
# Specify the path or change it below
$destDir = "C:\Download"

# Check if the folder exist if not create it 
 If (!(Test-Path $destDir)) {
   New-Item -Path $destDir -ItemType Directory
}
else {
   Write-Host "`n"
   Write-Host "Directory already exists!" -ForegroundColor "red"
   Write-Host "`n"
}

# Start the Download
Get-Content $dir\urls.txt |
    Foreach-Object { 
        write-host -ForegroundColor "cyan" "Downloading  " + $_ 
        try {
            $target = join-path $destDir ([io.path]::getfilename($_))
            $web.DownloadFile($_, $target)
        } catch {
            $_.Exception.Message
        }
} 

#Write the completed message
Write-Host "`n`n`n"
Write-Host "Download Completed" -foregroundcolor "green"
Write-Host "`n`n`n"

#it Opens the destination folder using Explorer.exe
ii $destDir