﻿##########################################################################################
#Author Thiago Beier thiago.beier@gmail.com 
#Version: 1.0 
#Toronto,CANADA 
#Powershell Functions To verify if a user has the proxyaddresses attribute set in ADDS
##########################################################################################



Import-Module ActiveDirectory
$users = Get-ADUser -LDAPFilter "(mail=*)" -Properties mail,proxyaddresses -ResultSetSize $null

foreach($user in $users){
	if($user.proxyaddresses -contains "smtp:$($user.mail)"){
		write-host $user.name "ProxyAddresses has been set" -ForegroundColor green
# $user.proxyaddresses 
	} else {
        write-host $user.name "ProxyAddresses has not been set" -ForegroundColor red #>> C:\temp\hasnot.txt
            }
}