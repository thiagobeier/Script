﻿################################################################################   
#Author Thiago Beier thiago.beier@gmail.com   
#Version: 1.0 - 2019-07-30  
#Export SCCM queries
#Export each query separately 
#Tested with SCCM Version: 1902 
#Toronto,CANADA   
#email: thiago.beier@gmail.com 
#https://www.linkedin.com/in/tbeier/ 
################################################################################  

$exportpath = "D:\Export"

$querylist = Get-CMQuery | select name
foreach ($queryitem in $querylist) {
    $name = $queryitem.name
    #write-host querylist -ForegroundColor Green
    write-host $name -ForegroundColor Green
    Export-CMQuery -Name $name -ExportFilePath $exportpath\queries\$name.mof
  }
