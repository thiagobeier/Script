﻿################################################################################   
#Author Thiago Beier thiago.beier@gmail.com   
#Version: 1.0 - 2019-07-30  
#Export SCCM Packages and its contents
#Export each package separately 
#Tested with SCCM Version: 1902 
#Toronto,CANADA   
#email: thiago.beier@gmail.com 
#https://www.linkedin.com/in/tbeier/ 
################################################################################  

$exportpath = "D:\Export"

$listpackage = Get-CMPackage | select Name
foreach ($pkgname in $listpackage) {
    $name = $pkgname.Name
    #write-host $pkgname.Name -ForegroundColor Green
    write-host $name -ForegroundColor Green
    Export-CMPackage -Name $name -ExportFilePath $exportpath\pkg\$name.zip
  }
