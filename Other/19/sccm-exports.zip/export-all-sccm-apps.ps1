﻿################################################################################   
#Author Thiago Beier thiago.beier@gmail.com   
#Version: 1.0 - 2019-07-30  
#Export SCCM Apps and its contents
#Export each apps separately 
#Tested with SCCM Version: 1902 
#Toronto,CANADA   
#email: thiago.beier@gmail.com 
#https://www.linkedin.com/in/tbeier/ 
################################################################################  

$exportpath = "D:\Export"

$listappsname = Get-CMApplication | select LocalizedDisplayName
foreach ($appname in $listappsname) {
    $appsname = $appname.LocalizedDisplayName
    write-host $appsname -ForegroundColor Green
    Export-CMApplication -Name $appsname -Path $exportpath\apps\$appsname.zip
  }