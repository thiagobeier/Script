﻿################################################################################   
#Author Thiago Beier thiago.beier@gmail.com   
#Version: 1.0 - 2019-07-30  
#Export SCCM Collections info
#Export each collection info separately 
#Tested with SCCM Version: 1902 
#Toronto,CANADA   
#email: thiago.beier@gmail.com 
#https://www.linkedin.com/in/tbeier/ 
################################################################################  

$exportpath = "D:\Export"

#Get-CMCollection
$querylist = Get-CMCollection  #| select collectionid,name
foreach ($queryitem in $querylist) {
    $name = $queryitem.Name
    $colid = $queryitem.collectionid
    write-host $name -ForegroundColor Green
    Write-Host $colid-$name -ForegroundColor Yellow
    Get-CMCollection -Id $colid | Get-CMCollectionMember | select Name,primaryuser,lastlogonuser,currentlogonuser,adsitename | Export-csv "$exportpath\collections\$colid-$name.csv" -Encoding UTF8
  }
